//
//  ViewController.m
//  IncomingCallEvent
//
//  Created by venkatesh on 1/12/18.
//  Copyright © 2018 venkatesh. All rights reserved.
//

#import "ViewController.h"
#import <CallKit/CXCallObserver.h>
#import <CallKit/CXCall.h>
#import <AddressBook/AddressBook.h>
#import <Contacts/Contacts.h>
#import <ContactsUI/ContactsUI.h>

@interface ViewController ()<CXCallObserverDelegate>

@property ( nonatomic,strong) CXCallObserver *callObserver;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
   
    
  // [self contactPermission];
    
   // [self performSelector:@selector(updateContact) withObject:nil afterDelay:8.0];
    
    
    _callObserver = [CXCallObserver new];
    [_callObserver setDelegate:self queue:dispatch_get_main_queue()];
    
   //  [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(callObserver:) name:@"callObserver" object:nil];
}



- (void)callObserver:(CXCallObserver *)callObserver callChanged:(CXCall *)call{
    
   // [self updateContact];
    
    if (call == nil || call.hasEnded == YES) {
        NSLog(@"CXCallState : Disconnected");
    }
    
    if (call.isOutgoing == YES && call.hasConnected == NO) {
        NSLog(@"CXCallState : Dialing");
    }
    
    if (call.isOutgoing == NO  && call.hasConnected == NO && call.hasEnded == NO && call != nil) {
        NSLog(@"CXCallState : Incoming");
    }
    
    if (call.hasConnected == YES && call.hasEnded == NO) {
        NSLog(@"CXCallState : Connected");
    }
}



//#pragma mark _____________________________________save contact
//-(void)contactPermission
//{
//
//    CNAuthorizationStatus status = [CNContactStore authorizationStatusForEntityType:CNEntityTypeContacts];
//
//    if (status == CNAuthorizationStatusDenied || status == CNAuthorizationStatusRestricted) {
//
//        UIAlertController *alert = [UIAlertController alertControllerWithTitle:nil message:@"This app previously was refused permissions to contacts; Please go to settings and grant permission to this app so it can add the desired contact" preferredStyle:UIAlertControllerStyleAlert];
//
//        [alert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil]];
//
//        [self presentViewController:alert animated:TRUE completion:nil];
//
//        return;
//
//    }
//
//    CNContactStore *store = [[CNContactStore alloc] init];
//
//    [store requestAccessForEntityType:CNEntityTypeContacts completionHandler:^(BOOL granted, NSError * _Nullable error) {
//
//        if (!granted) {
//
//            dispatch_async(dispatch_get_main_queue(), ^{
//
//                // user didn't grant access;
//
//
//            });
//
//            return;
//
//        }
//
//
//
//    }];
//}
//
//-(void)updateContact
//{
//    //Create repository objects contacts
//    CNContactStore *contactStore = [[CNContactStore alloc] init];
//
//    NSArray *keys = [[NSArray alloc]initWithObjects:CNContactIdentifierKey, CNContactEmailAddressesKey, CNContactBirthdayKey, CNContactImageDataKey, CNContactPhoneNumbersKey, CNContactViewController.descriptorForRequiredKeys, nil];
//
//    // Create a request object
//    CNContactFetchRequest *request = [[CNContactFetchRequest alloc] initWithKeysToFetch:keys];
//    request.predicate = nil;
//
//    [contactStore enumerateContactsWithFetchRequest:request
//                                              error:nil
//                                         usingBlock:^(CNContact* __nonnull contact, BOOL* __nonnull stop)
//     {
//         // Contact one each function block is executed whenever you get
//         NSString *phoneNumber1 = @"";
//         if( contact.phoneNumbers)
//             phoneNumber1 = [[[contact.phoneNumbers firstObject] value] stringValue];
//
//         NSLog(@"phoneNumber = %@", phoneNumber1);
//         NSLog(@"givenName = %@", contact.givenName);
//         NSLog(@"familyName = %@", contact.familyName);
//         NSLog(@"email = %@", contact.emailAddresses);
//
//
//
//
//         CNMutableContact *update = contact.mutableCopy;
//         CNSaveRequest *saveRequest = [[CNSaveRequest alloc] init];
//         // NSLog(@"%@", contact.givenName);
//
//         if([contact.givenName isEqualToString:@"YES Priority"] || [contact.givenName isEqualToString: @"YES Priority  Unknown"] || [contact.givenName isEqualToString: @"YES Priority  UNKNOWN"]){
//
//            update.givenName = [NSString stringWithFormat:@"YES Priority_%@",@"TEST4"];
//
//
//             NSLog(@"test");
//             [saveRequest updateContact:update];
//
//         }
//
//
//
//         [contactStore executeSaveRequest:saveRequest error:nil];
//     }];
//}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
