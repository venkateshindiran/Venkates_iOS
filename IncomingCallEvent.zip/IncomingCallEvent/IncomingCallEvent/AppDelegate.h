//
//  AppDelegate.h
//  IncomingCallEvent
//
//  Created by venkatesh on 1/12/18.
//  Copyright © 2018 venkatesh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

